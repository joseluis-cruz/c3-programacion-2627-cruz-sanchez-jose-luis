 // Used pins
#define SERVO1 3  // Servo motor on pin 3 (orange wire)
#define LEDRED 7  // Red led (brown wire)
#define LEDBLU 4  // Blue led (blue wire)
#define BTNINC 6  // INCrease BuTtoN on pin 6 (light green wire)
#define BTNDEC 5  // DECrease BuTtoN on pin 5 (dark green wire)

#define SERVO_STEP 2 // Grados que incrementa o decrementa en cada pulsación
#define LED_MS_ON 1000 // Tiempo de encendido de los leds

// Include the library for controlling servo motors
#include <Servo.h>

// Create a Servo object to control the servo motor
Servo servoMotor1;

// Variable to store the current servo position
int servo1Position;

void setup() // Runs only once, at startup
{
  // Configure the digital pins:
  pinMode(LEDRED, OUTPUT); 
  pinMode(LEDBLU, OUTPUT); 
  pinMode(BTNINC, INPUT_PULLUP); // HIGH = not pressed, LOW = pressed
  pinMode(BTNDEC, INPUT_PULLUP); // HIGH = not pressed, LOW = pressed

  // Attach the servo motor to its pin
  servoMotor1.attach(SERVO1);

  // Set the initial servo position to 0 degrees
  servo1Position = 0;

  // Move the servo to the initial position
  servoMotor1.write(servo1Position);

  // Set the initial status of leds (turned off)
  digitalWrite(LEDRED,LOW);
  digitalWrite(LEDBLU,LOW);

}

void loop() // Runs continuously after setup()
{
  delay(10); // Prevents the simulator from being overloaded
  CheckButton(BTNINC,LEDRED,+1);
  CheckButton(BTNDEC,LEDBLU,-1);
}

void CheckButton(byte button, byte led, int sign)
{
  if (!digitalRead(button)) // If button is pressed
  {
    // Increase the servo position by "SERVO_STEP" degrees
    if (
         ((sign>0)&&(servo1Position<180))
         ||
         ((sign<0)&&(servo1Position>0))
       )
    {
      servo1Position += SERVO_STEP*sign;
    }
    else
    {
      digitalWrite(led,HIGH);
      delay(LED_MS_ON);
      digitalWrite(led,LOW);
    }  

    // Send the new position to the servo motor
    servoMotor1.write(servo1Position);

    // Wait 20 ms to slow down the movement
    delay(10);
  }  
}