#define BUTTON 2
#define LED 13

#define ESTADO_INICIAL 0
#define ESTADO_ESPERANDO_LUZ 1
#define ESTADO_LUZ_ENCENDIDA 2

byte estado = ESTADO_INICIAL; // nos ayuda a saber en qué momento pulsamos el botón, para actuar según dicho estado
bool boton_pulsado = false; // nos ayuda a detectar que el botón no estaba pulsado, de forma que sólo atendamos su pulsación una vez, hasta que se vuelva a liberar

void setup()
{  
  pinMode(BUTTON, INPUT_PULLUP);
  pinMode(LED, OUTPUT);
  digitalWrite(LED,LOW);
  Serial.begin(9600);
  Serial.println("Pulsa el botón para iniciar. Permanece atento y pulsa el botón tan rápido como veas que se enciende la luz.");
}

void loop()
{
  //evitamos que se sobrecarge el emulador
  delay(10);
  // si se pulsa el botón 
  if (!digitalRead(BUTTON))
  {
    if (!boton_pulsado) // si previamente no estaba pulsado
    {
      boton_pulsado = true; // recordamos que se ha pulsado, para evitar que el switch se ejecute repetidamente      
      switch (estado)
      {
        case ESTADO_INICIAL:
          Serial.println("Has pulsado en estado inicial.");
          break;
        case ESTADO_ESPERANDO_LUZ:
          Serial.println("Has pulsado antes de que el led se encienda.");
          break;
        case ESTADO_LUZ_ENCENDIDA:
          Serial.println("Has pulsado tras el encendido del led.");
          break;
      }
    }    
  }
  else if (boton_pulsado) // borramos el flag de botón pulsado
  {
    boton_pulsado = false;
  }
}
