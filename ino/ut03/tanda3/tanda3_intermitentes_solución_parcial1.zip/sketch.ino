#define BTNIZQ 5
#define BTNDER 6
#define LEDIZQ 4
#define LEDDER 7

#define BLINK_MS 500 //3.1

byte estado;
/*
  Estado del sistema:
  0 - Ambos intermitentes apagados
  1 - Intermitente izquierdo parpadeando
  2 - Intermitente derecho parpadeando
*/

void setup() // Runs only once, at startup
{
  // modos de entrada o salida y apagar leds
  pinMode(BTNIZQ, INPUT_PULLUP);
  pinMode(BTNDER, INPUT_PULLUP);
  pinMode(LEDIZQ, OUTPUT);
  pinMode(LEDDER, OUTPUT);
  digitalWrite(LEDIZQ,LOW);
  digitalWrite(LEDDER,LOW);
  estado = 0; //
}

void loop() // Runs continuously after setup()
{
  delay(10); // para no saturar el emulador

  //compruebo los dos botones con el mismo método refactorizado
  CheckBoton(BTNIZQ,1);
  CheckBoton(BTNDER,2);

  if (estado==1)
  {
    digitalWrite(LEDIZQ,HIGH);
    delay(BLINK_MS);
    digitalWrite(LEDIZQ,LOW);
    delay(BLINK_MS);
  }
  if (estado==2)
  {
    digitalWrite(LEDDER,HIGH);
    delay(BLINK_MS);
    digitalWrite(LEDDER,LOW);
    delay(BLINK_MS);
  }
}


void CheckBoton(byte boton, byte estado_encendido)
{
  if (!digitalRead(boton))
  {
    if (estado==estado_encendido)
    {
      estado = 0;
    }
    else
    {
      estado = estado_encendido;
    }    
    // ahora voy a esperar a que el botón no esté pulsado
    do
    {
      delay(10);
    } while (!digitalRead(boton));
  }

}