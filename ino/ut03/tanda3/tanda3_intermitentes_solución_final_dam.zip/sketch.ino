#define LEDIZQ 4
#define LEDDER 7
#define BTNIZQ 5
#define BTNDER 6

#define BLINK_MS 500

#define ESTADO_TODO_APAGADO 0
#define ESTADO_PARPADEA_IZQUIERDA 1
#define ESTADO_PARPADEA_DERERECHA 2
#define ESTADO_EMERGENCIA 3

byte estado;

void setup() // Runs only once, at startup
{
  pinMode(LEDIZQ, OUTPUT);
  pinMode(LEDDER, OUTPUT);
  pinMode(BTNIZQ, INPUT_PULLUP);
  pinMode(BTNDER, INPUT_PULLUP);
  digitalWrite(LEDIZQ, LOW);
  digitalWrite(LEDDER, LOW);
  estado = ESTADO_TODO_APAGADO;
}

void loop() // Runs continuously after setup()
{
  // FASE 1: Comprobamos pulsación de botones...
  // ...para cambiar el estado cuando se pulsan

  // si se pulsan ambos botones
  if ((!digitalRead(BTNIZQ))&&(!digitalRead(BTNDER)))
  {
    // compruebo si previamente está ya parpadeando
    if (estado==ESTADO_EMERGENCIA)
    { // en ese caso, lo apago
      estado = ESTADO_TODO_APAGADO; 
    }
    else 
    { // y si no estaba parpadeando a la izquierda, hago que lo esté
      estado = ESTADO_EMERGENCIA; 
    }    
  }
  // fuerzo un "else" para que no se compruebe si ya se cumple la de arriba
  else if (!digitalRead(BTNIZQ)) // si se pulsa el botón de la izquierda
  {
    // compruebo si previamente está ya parpadeando
    if (estado==ESTADO_PARPADEA_IZQUIERDA)
    { // en ese caso, lo apago
      estado = ESTADO_TODO_APAGADO; 
    }
    else 
    { // y si no estaba parpadeando a la izquierda, hago que lo esté
      estado = ESTADO_PARPADEA_IZQUIERDA; 
    }    
  }
  else if (!digitalRead(BTNDER))
  {
    if (estado==ESTADO_PARPADEA_DERERECHA)
    {
      estado = ESTADO_TODO_APAGADO; 
    }
    else
    {
      estado = ESTADO_PARPADEA_DERERECHA; 
    }
  }
  // FASE 2: Encendemos y apagamos luces...
  // ...según el estado en el que estemos
  if ((estado==ESTADO_PARPADEA_IZQUIERDA)||(estado==ESTADO_EMERGENCIA))
  {
    digitalWrite(LEDIZQ, HIGH);
  }
  if ((estado==ESTADO_PARPADEA_DERERECHA)||(estado==ESTADO_EMERGENCIA))
  {
    digitalWrite(LEDDER, HIGH);
  }
  delay(BLINK_MS);
  digitalWrite(LEDIZQ, LOW);
  digitalWrite(LEDDER, LOW);
  delay(BLINK_MS);
  
}
