void setup() // Runs only once, at startup
{
}

void loop() // Runs continuously after setup()
{
}
