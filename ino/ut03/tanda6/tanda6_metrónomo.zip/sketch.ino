#define POTENCIOMETRO1 A0
#define BOTON1 7 // botón verde
#define SERVO1 6 // servomotor

#include <Servo.h> // Incluye la librería Servo

Servo servo1;
int servo1pos;
bool boton1pulsado=false;

void setup()
{
  pinMode(BOTON1, INPUT_PULLUP);
  servo1.attach(SERVO1);
  servo1pos = 0;
  servo1.write(servo1pos;)
  
  Serial.begin(9600);
  Serial.println("Programa inicializado");
}

void loop()
{
  delay(100);
  int valor_pot = analogRead(POTENCIOMETRO1);
  Serial.print("Valor del potenciómetro: ");
  Serial.println(valor_pot);
  //si se pulsa el botón 1
  if (!digitalRead(BOTON1))
  {
    // si antes no estaba pulsado
    if (!boton1pulsado)
    {
      Serial.println("Se ha pulsado el botón 1");
      boton1pulsado = true; // recordamos que se ha pulsado
    }
  }
  else if (boton1Pulsado) // dejamos de recordar que se ha pulsado
  {
    boton1Pulsado = false;
  }
}
