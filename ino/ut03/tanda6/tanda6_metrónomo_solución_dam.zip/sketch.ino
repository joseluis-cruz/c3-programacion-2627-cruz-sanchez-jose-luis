#define POTENCIOMETRO1 A0
#define BOTON1 7 // botón verde
#define SERVO1 6 // servomotor

#include <Servo.h> // Incluye la librería Servo

Servo servo1;
int servo1pos;
bool boton1pulsado=false;
//A6.1 inicializo con un valor que sé que va a cambiar cuando lea
int valor_pot_anterior = -1; 
//A6.3 defino el estado, que inicialmente será "subiendo"
//int estado = 1;
//A6.4 Para este apartado, hago que comience parado:
int estado = 0;

void setup()
{
  pinMode(BOTON1, INPUT_PULLUP);
  servo1.attach(SERVO1);
  servo1pos = 0;
  servo1.write(servo1pos);
  
  Serial.begin(9600);
  Serial.println("Programa inicializado");
}

void loop()
{
  //A6.3 Voy a actualizar la posicion del servo según el estado
  if (estado==1)
  {
    servo1pos += 10;
    servo1.write(servo1pos);
    if (servo1pos>=180)
    {
      estado=-1;
      Serial.println("Reboto para abajo");
    }
  }
  else if (estado==-1)
  {
    servo1pos -= 10;
    servo1.write(servo1pos);
    if (servo1pos<=0)
    {
      estado=1;
      Serial.println("Reboto para arriba");
    }
  }
  int valor_pot = analogRead(POTENCIOMETRO1);
  //A6.1 Sólo imprimo si el valor recién leido es diferente del anterior
  if (valor_pot!=valor_pot_anterior)
  {
    Serial.print("Valor del potenciómetro: ");
    Serial.println(valor_pot);
    //A6.1 Recuerdo el valor actual como anterior para el siguiente loop
    valor_pot_anterior = valor_pot; 
    //A6.2 Calculo la posición para el servo con map
    /*
    servo1pos = map(valor_pot,0,1023,0,180);
    //...y envío esa posición
    servo1.write(servo1pos);
    */   
  }
  //A6.3 Vamos a hacer aquí la espera, una vez que tenemos el valor_pot actual
  int tiempo_espera = valor_pot / 10;
  delay(tiempo_espera);



  //si se pulsa el botón 1
  if (!digitalRead(BOTON1))
  {
    // si antes no estaba pulsado
    if (!boton1pulsado)
    {
      Serial.println("Se ha pulsado el botón 1");      
      boton1pulsado = true; // recordamos que se ha pulsado
      //A6.4 Voy a arrancar o parar el metrónomo, según sea su estado actual
      if (estado==0)
      {
        estado = 1;
      }
      else
      {
        estado = 0;
        servo1pos = 0;
        servo1.write(servo1pos);
      }
    }
  }
  else if (boton1pulsado) // dejamos de recordar que se ha pulsado
  {
    boton1pulsado = false;
  }
}
